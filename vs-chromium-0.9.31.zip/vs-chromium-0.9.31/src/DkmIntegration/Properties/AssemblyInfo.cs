﻿// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("VsChromium.DkmIntegration")]
[assembly: AssemblyDescription("Visual Studio debugger integration for VsChromium.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("VsChromium")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: InternalsVisibleTo("VsChromium, PublicKey=00240000048000009400000006020000002400005253413100040000010001008940df83f3c94726ad193d47bd911a0813615c2dd51918912ef5dc35bc3773b78fb6170266b114f17e7701175b13d6f1aac3caac4cc403fc1d6f57d453e951cffb5aab20584dedc82422302ea7a0c2c9f26652a22061f182c195c74c53179016c55a8312a30ad903fe60632bd3d8cf86ea5dcd492ed2f9242b5919e2d84a27c6")]