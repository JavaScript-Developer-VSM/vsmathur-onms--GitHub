﻿// Copyright 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

using System;

namespace VsChromium.DkmIntegration.Guids {
  public static class PortSupplier {
    public static readonly Guid Default = new Guid("708C1ECA-FF48-11D2-904F-00C04FA302A1");
  }
}
