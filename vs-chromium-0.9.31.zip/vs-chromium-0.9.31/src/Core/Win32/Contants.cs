namespace VsChromium.Core.Win32 {
  public static class Contants {
    public const uint INFINITE = 0xFFFFFFFF;
  }
}