namespace VsChromium.Core.Win32 {
  public static class HResults {
    public const int HR_ERROR_SEM_TIMEOUT = unchecked((int)0x80070079);
    public const int HR_ERROR_NOT_SUPPORTED = unchecked((int)0x80070032);
  }
}