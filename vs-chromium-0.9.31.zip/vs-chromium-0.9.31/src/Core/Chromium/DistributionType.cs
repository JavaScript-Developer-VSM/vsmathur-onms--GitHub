﻿namespace VsChromium.Core.Chromium {
  public enum DistributionType {
    Chromium,
    Chrome,
    Canary,
    Unknown
  }
}
