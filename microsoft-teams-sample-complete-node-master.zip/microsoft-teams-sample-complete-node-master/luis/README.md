# Files and Directories
* **Example.json**<br><br>
This file shows an example of a file that can be used to set up a Luis natural language recognizer.