/**
 * This file is blank on purpose and is here to do two tasks:
 *
 *  1.  Act as a placeholder so when the build step occurs and the typescript
 *      is transpiled, the src and test directory hierarchy remains within the build directory
 *
 *  2.  Act as a placeholder to show where tests can be located
 *
 */
