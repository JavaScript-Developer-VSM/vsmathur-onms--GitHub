# Files and Directories
* **test.ts**<br><br>
As the file says, this is directory and file are used for two purposes:  1. Act as a placeholder so when the build step occurs and the typescript is transpiled, the src and test directory hierarchy remains within the build directory 2. Act as a placeholder to show where tests can be located