# Files and Directories
* **assets**<br><br>
This directory holds the images used by the bot and tab.

* **tab**<br><br>
This direcotry holds the tabConfig directory which holds the html and javascript files used to run the configuration page of the configurable tab.  The javascript file, tabConfig.js, creates the actual configurable tab.
