JavaScript
==========

JavaScript and Google App Script code

Code here is experimental and may change so there are no guarantees about its quality.
Test scripts are given either in the documentation or as separate files.  Always try them
first before using any of the code.  
If the code is useful to you please feel free to use it but always test that it performs as YOU expect.
If you find bugs or have suggestions, please feel free to email me at mick@javascript-spreadsheet-programming.com.
