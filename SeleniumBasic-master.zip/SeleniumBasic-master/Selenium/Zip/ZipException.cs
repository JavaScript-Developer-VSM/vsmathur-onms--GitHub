﻿using System;

namespace Selenium.Zip {

    class ZipException : Exception {
        public ZipException(string message)
            : base(message) { }
    }

}
